<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompanyInvoiceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company_invoice', function (Blueprint $table) {
            $table->increments('company_invoice_id');
            $table->string('company_invoice_num', 45);
            $table->string('company_invoice_text', 45);
            $table->integer('company_invoice')->unsigned();
            $table->integer('company_invoice_builder')->unsigned();
            $table->foreign('company_invoice')->references('company_id')->on('company');
            $table->foreign('company_invoice_builder')->references('user_id')->on('user');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company_invoice');
    }
}
