#!/bin/bash
Time=$(date +"%Y%m%d_%H%M")

tar zcvf /var/www/e8d/backup/file_$Time.tar.gz /var/www/e8d/wp-content/* --exclude=backups-dup-pro --exclude=updraft --exculd=cache

echo $Time"~~~Auto Git Done~~~" >> /var/www/e8d/backup/back.log

